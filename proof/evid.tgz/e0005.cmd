timeout 120s python3 - <<'PY'
from pathlib import Path
from collections import defaultdict
from math import comb, factorial
import json,time,sys,resource

# Fixed known-term mathematical diagnostics; no unknown terms or production code.
known=dict(tuple(map(int,s.split())) for s in Path('data/b180207.txt').read_text().splitlines() if s.strip())
rows=[]
for nmax in range(12,17):
    N=nmax-1
    begin=time.perf_counter()
    F=[0]*(1<<N)
    current={(0,0,0,0):1}
    layers=[]
    for depth in range(N+1):
        t0=time.perf_counter()
        for (mask,a,b,c),count in current.items():
            F[mask]+=count
        following=defaultdict(int)
        attempts=0
        accepted=0
        if depth<N:
            for (mask,a,b,c),count in current.items():
                s=a+b+c
                for v in range(max(1,s),N+1):
                    attempts+=1
                    bit=1<<(v-1)
                    if not mask&bit:
                        following[(mask|bit,b,c,v-s)]+=count
                        accepted+=1
        layers.append({'depth':depth,'states':len(current),'next_states':len(following),
                       'simultaneous_states':len(current)+len(following),
                       'value_checks':attempts,'valid_transitions':accepted,
                       'wall_seconds':time.perf_counter()-t0})
        current=following
    counts=[]
    for n in range(1,nmax+1):
        full=(1<<(n-1))-1
        total=sum(F[m]*F[full^m] for m in range(full+1))
        assert total==known[n],(nmax,n,total)
        counts.append({'n':n,'count':total})
    rows.append({'nmax':nmax,'counts':counts,'layers':layers,
                 'total_states':sum(z['states'] for z in layers),
                 'total_value_checks':sum(z['value_checks'] for z in layers),
                 'total_valid_transitions':sum(z['valid_transitions'] for z in layers),
                 'peak_layer_states':max(z['states'] for z in layers),
                 'peak_simultaneous_states':max(z['simultaneous_states'] for z in layers),
                 'full_positive_tail_count':F[-1],
                 'maximum_F':max(F),'wall_seconds':time.perf_counter()-begin})
    out={'status':'PASS_COMPLETED_ANCHORS','scope':'Known terms only, nmax=12..16; nmax16 held out from growth fitting',
         'python':sys.version,'rows':rows,'process_maxrss_kib_linux':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
    Path('outputs/sidechk.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in rows[-1].items() if k not in ('counts','layers')}),flush=True)
PY
