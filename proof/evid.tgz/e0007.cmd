timeout 120s python3 - <<'PY'
from pathlib import Path
from itertools import combinations
from collections import defaultdict
import json,time,hashlib,resource

# Fixed n=16 known-term partition diagnostics, not a production implementation.
N=15
baseline=None
rows=[]
for d in range(5):
    start=time.perf_counter()
    F=[0]*(1<<N)
    if d:
        for mask in range(1<<N):
            if mask.bit_count()<d:
                F[mask]=1
    units=[]
    for vals in combinations(range(1,N+1),d):
        tu=time.perf_counter()
        mask=sum(1<<(v-1) for v in vals)
        diffs=[v-(vals[i-1] if i else 0) for i,v in enumerate(vals)]
        triple=([0,0,0]+diffs)[-3:]
        current={(mask,*triple):1}
        states=checks=valid=pairpeak=0
        for t in range(d,N+1):
            following=defaultdict(int)
            for (m,a,b,c),count in current.items():
                F[m]+=count
                if t<N:
                    s=a+b+c
                    for v in range(max(1,s),N+1):
                        checks+=1
                        bit=1<<(v-1)
                        if not m&bit:
                            following[(m|bit,b,c,v-s)]+=count
                            valid+=1
            states+=len(current)
            pairpeak=max(pairpeak,len(current)+len(following))
            current=following
        units.append({'prefix':list(vals),'states':states,'checks':checks,'valid_transitions':valid,
                      'pair_peak':pairpeak,'seconds':time.perf_counter()-tu})
    if baseline is None:
        baseline=F
    assert F==baseline,(d,'coefficient discrepancy')
    full=(1<<N)-1
    total=sum(F[m]*F[full^m] for m in range(full+1))
    assert total==35154332
    digest=hashlib.sha256(('\n'.join(map(str,F))+'\n').encode()).hexdigest()
    row={'n':16,'prefix_depth':d,'units':len(units),'total_states':sum(z['states'] for z in units),
         'total_value_checks':sum(z['checks'] for z in units),
         'total_valid_transitions':sum(z['valid_transitions'] for z in units),
         'largest_unit_states':max(z['states'] for z in units),
         'largest_unit_value_checks':max(z['checks'] for z in units),
         'peak_unit_adjacent_states':max(z['pair_peak'] for z in units),
         'largest_unit_seconds':max(z['seconds'] for z in units),
         'wall_seconds':time.perf_counter()-start,'F_sha256_decimal_lines':digest,'a16':total,
         'all_units':units}
    rows.append(row)
    Path('outputs/partchk.json').write_text(json.dumps({'scope':'Known n=16 only, exact equality of all 32768 F coefficients; shared mathematical kernel',
        'rows':rows,'process_maxrss_kib_linux':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2)+'\n')
    print(json.dumps({k:v for k,v in row.items() if k!='all_units'}),flush=True)
PY
