timeout 60s python3 - <<'PY'
from pathlib import Path
from itertools import permutations
from math import comb, factorial
from collections import defaultdict
import json, platform, sys, time, resource

# Disposable known-term replay only. Fixed scope n<=12; never computes n=17.
known = dict(tuple(map(int, s.split())) for s in Path('data/b180207.txt').read_text().splitlines() if s.strip())
start = time.perf_counter()
rows = []
for n in range(1, 10):
    accepted = 0
    byzero = [0] * n
    for p in permutations(range(n)):
        curr = [0]*4
        low = [0]*4
        for i in range(n-1):
            r = i % 4
            curr[r] += p[i+1]-p[i]
            low[r] = min(low[r], curr[r])
        deficit = -sum(low)
        criterion = deficit <= p[0]
        j = p.index(0)
        x = [None]*(n+3)
        x[j:j+4] = [0]*4
        for i in range(j,n-1):
            x[i+4] = x[i]+p[i+1]-p[i]
        for i in range(j-1,-1,-1):
            x[i] = x[i+4]-p[i+1]+p[i]
        anchor = min(x) >= 0
        assert criterion == anchor, (n,p)
        if anchor:
            assert deficit == p[0], (n,p,deficit)
            assert tuple(sum(x[i:i+4]) for i in range(n)) == p
            accepted += 1
            byzero[j] += 1
    assert accepted == known[n]
    assert byzero == byzero[::-1]
    rows.append({'n':n,'permutations_examined':factorial(n),'count':accepted,'by_zero_position':byzero})

dp_rows = []
timing = None
for n in range(1,13):
    t0 = time.perf_counter()
    current = {(0,a,b,c):1 for a in range(n) for b in range(n-a) for c in range(n-a-b)}
    layer_sizes = [len(current)]
    pair_peak = 0
    for t in range(n):
        following = defaultdict(int)
        for (mask,a,b,c), multiplicity in current.items():
            s = a+b+c
            for v in range(s,n):
                if not (mask >> v) & 1:
                    following[mask | (1 << v),b,c,v-s] += multiplicity
        pair_peak = max(pair_peak, len(current)+len(following))
        current = following
        layer_sizes.append(len(current))
    total = sum(current.values())
    assert total == known[n], (n,total)
    dp_rows.append({'n':n,'count':total,'layer_state_counts':layer_sizes,'peak_adjacent_layer_states':pair_peak})
    if n == 12:
        timing = {'n':12,'wall_seconds':time.perf_counter()-t0,'method':'tuple-key Python window-state DP, known-term replay only'}

n = 17
triples = comb(n+2,3)
scale = {'n':n,'factorial':factorial(n),'factorial_bits':factorial(n).bit_length(),
         'triples':triples,'all_mask_states_upper':triples*2**n,
         'peak_layer_states_upper':triples*comb(n,n//2),
         'peak_adjacent_layer_states_upper':triples*comb(n+1,(n+1)//2),
         'unused_value_transition_attempts_upper':triples*n*2**(n-1),
         'all_value_loop_checks_upper':triples*n*2**n,
         'partial_path_count_upper':triples*factorial(n),
         'partial_path_count_upper_bits':(triples*factorial(n)).bit_length()}
out = {'scope':'BOUNDED TRIAGE CHECK; no production candidate or campaign',
       'python':sys.version,'platform':platform.platform(),'permutation_replay':rows,
       'dp_replay':dp_rows,'single_timing_probe':timing,'scale_exact_arithmetic':scale,
       'total_wall_seconds':time.perf_counter()-start,
       'process_maxrss_kib_linux':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
       'status':'PASS'}
Path('outputs/probe.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
PY
