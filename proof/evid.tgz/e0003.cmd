timeout 90s python3 - <<'PY'
from pathlib import Path
from collections import defaultdict
import time,json,resource
resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3))
n=16
t0=time.perf_counter()
current={(0,a,b,c):1 for a in range(n) for b in range(n-a) for c in range(n-a-b)}
layers=[]
for t in range(n):
    following=defaultdict(int)
    for (mask,a,b,c),count in current.items():
        s=a+b+c
        for v in range(s,n):
            if not (mask>>v)&1:
                following[(mask|(1<<v),b,c,v-s)]+=count
    layers.append({'t':t,'states':len(current),'next_states':len(following)})
    current=following
total=sum(current.values())
assert total==35154332
out={'scope':'Known n=16 only; unrestricted initial-triple DP comparator',
     'n':n,'count':total,'layers':layers,'wall_seconds':time.perf_counter()-t0,
     'peak_layer_states':max(max(z['states'],z['next_states']) for z in layers),
     'peak_adjacent_states':max(z['states']+z['next_states'] for z in layers),
     'process_maxrss_kib_linux':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
     'status':'PASS'}
Path('outputs/full16.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
PY
