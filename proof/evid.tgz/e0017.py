from pathlib import Path
import subprocess,json,hashlib,sys
r=Path(__file__).resolve().parents[2];out=r/'outputs/valid22';exe=out/'iecheck'
known=[tuple(map(int,x.split())) for x in (r/'data/b180207.txt').read_text().splitlines() if x.strip()]
rows=[]
for n,expected in known:
    p=subprocess.run([str(exe),str(n)],capture_output=True,timeout=30);assert p.returncode==0,(n,p.stderr)
    data=json.loads(p.stdout);assert data['status']=='COMPLETE' and int(data['count'])==expected and data['subsets']==1<<(n-1)
    assert int(data['absolute_sum_bound'])==(1<<(n-1))*n*((n-1)**(n-1))
    rows.append(data);print(n,'PASS',data['wall_seconds'],flush=True)
for text in ('0','23','-1','1x','1 2',''):
    p=subprocess.run([str(exe),text],capture_output=True,timeout=2);assert p.returncode==2 and not p.stdout
for n in (1,2,6):
    dst=out/f'qwin{n}.json';p=subprocess.run(['/usr/bin/python3','-B',str(r/'validation/window_check.py'),'--n',str(n),'--out',str(dst),'--memory-gib','1'],capture_output=True,timeout=10)
    assert p.returncode==0 and json.loads(dst.read_text())['count']==known[n-1][1]
(out/'qualify.json').write_text(json.dumps({'status':'PASS','known_domain':'1..16 IE complete; unrestricted wrapper1,2,6 plus inherited full16','ie_rows':rows,'invalid_cli_rejections':6,'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()},indent=2)+'\n')
